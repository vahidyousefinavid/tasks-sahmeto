import './App.css';
import MainScreen from './screens/Main';

function App() {
  return (
    <div className="App">
      <MainScreen />
    </div>
  );
}

export default App;
